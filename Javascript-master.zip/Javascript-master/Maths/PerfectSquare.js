/**
 * Author: dephraiim
 * License: GPL-3.0 or later
 *
 */

const perfectSquare = (num) => Math.sqrt(num) ** 2 === num

export { perfectSquare }
