/**
 * Author: dephraiim
 * License: GPL-3.0 or later
 *
 */

const perfectCube = (num) => Math.round(num ** (1 / 3)) ** 3 === num

export { perfectCube }
